const db = require('../config/database');
const nodemailer = require('nodemailer');

const bookingController = {
    async createBooking(req, res) {
        try {
            const { roomId, checkInDate, checkOutDate, totalPrice } = req.body;
            const userId = req.user.userId;

            // Check if room is available for the selected dates
            const conflictingBookings = await db.query(
                `SELECT * FROM bookings 
                WHERE room_id = ? 
                AND ((check_in_date BETWEEN ? AND ?) 
                OR (check_out_date BETWEEN ? AND ?))
                AND status != 'cancelled'`,
                [roomId, checkInDate, checkOutDate, checkInDate, checkOutDate]
            );

            if (conflictingBookings.length > 0) {
                return res.status(400).json({ message: 'Room not available for selected dates' });
            }

            // Create booking
            const result = await db.query(
                'INSERT INTO bookings (user_id, room_id, check_in_date, check_out_date, total_price) VALUES (?, ?, ?, ?, ?)',
                [userId, roomId, checkInDate, checkOutDate, totalPrice]
            );

            // Send confirmation email
            const transporter = nodemailer.createTransport({
                service: 'gmail',
                auth: {
                    user: process.env.EMAIL_USER,
                    pass: process.env.EMAIL_PASS
                }
            });

            const [user] = await db.query('SELECT email FROM users WHERE id = ?', [userId]);
            const [room] = await db.query('SELECT room_number FROM rooms WHERE id = ?', [roomId]);

            await transporter.sendMail({
                from: process.env.EMAIL_USER,
                to: user.email,
                subject: 'Booking Confirmation',
                html: `
                    <h1>Booking Confirmation</h1>
                    <p>Thank you for booking with us!</p>
                    <p>Room: ${room.room_number}</p>
                    <p>Check-in: ${checkInDate}</p>
                    <p>Check-out: ${checkOutDate}</p>
                    <p>Total: $${totalPrice}</p>
                `
            });

            res.status(201).json({
                message: 'Booking created successfully',
                bookingId: result.insertId
            });
        } catch (error) {
            res.status(500).json({ message: 'Error creating booking', error: error.message });
        }
    },

    async getUserBookings(req, res) {
        try {
            const userId = req.user.userId;
            const bookings = await db.query(
                `SELECT b.*, r.room_number, r.room_type 
                FROM bookings b 
                JOIN rooms r ON b.room_id = r.id 
                WHERE b.user_id = ?
                ORDER BY b.created_at DESC`,
                [userId]
            );
            res.json(bookings);
        } catch (error) {
            res.status(500).json({ message: 'Error fetching bookings', error: error.message });
        }
    }
};

module.exports = bookingController; 