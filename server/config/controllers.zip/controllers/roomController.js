const db = require('../config/database');

const roomController = {
    async getAllRooms(req, res) {
        try {
            const { type, minPrice, maxPrice, capacity } = req.query;
            let query = 'SELECT * FROM rooms WHERE 1=1';
            const params = [];

            if (type) {
                query += ' AND room_type = ?';
                params.push(type);
            }
            if (minPrice) {
                query += ' AND price >= ?';
                params.push(minPrice);
            }
            if (maxPrice) {
                query += ' AND price <= ?';
                params.push(maxPrice);
            }
            if (capacity) {
                query += ' AND capacity >= ?';
                params.push(capacity);
            }

            const rooms = await db.all(query, params);
            res.json(rooms);
        } catch (error) {
            res.status(500).json({ message: 'Error fetching rooms', error: error.message });
        }
    },

    async getRoomById(req, res) {
        try {
            const { id } = req.params;
            const room = await db.get('SELECT * FROM rooms WHERE id = ?', [id]);
            
            if (!room) {
                return res.status(404).json({ message: 'Room not found' });
            }
            
            res.json(room);
        } catch (error) {
            res.status(500).json({ message: 'Error fetching room', error: error.message });
        }
    }
};

module.exports = roomController; 