const db = require('../config/database');
const bcrypt = require('bcryptjs');

const userController = {
    async getProfile(req, res) {
        try {
            const [user] = await db.query(
                'SELECT id, username, email, created_at FROM users WHERE id = ?',
                [req.user.userId]
            );
            
            if (!user) {
                return res.status(404).json({ message: 'User not found' });
            }
            
            res.json(user);
        } catch (error) {
            res.status(500).json({ message: 'Error fetching profile', error: error.message });
        }
    },

    async updateProfile(req, res) {
        try {
            const { username, email } = req.body;
            const userId = req.user.userId;

            // Check if email is already taken
            if (email) {
                const [existingUser] = await db.query(
                    'SELECT id FROM users WHERE email = ? AND id != ?',
                    [email, userId]
                );
                if (existingUser) {
                    return res.status(400).json({ message: 'Email already in use' });
                }
            }

            await db.query(
                'UPDATE users SET username = ?, email = ? WHERE id = ?',
                [username, email, userId]
            );

            res.json({ message: 'Profile updated successfully' });
        } catch (error) {
            res.status(500).json({ message: 'Error updating profile', error: error.message });
        }
    }
};

module.exports = userController; 